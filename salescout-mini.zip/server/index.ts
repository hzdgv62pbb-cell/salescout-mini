import express from "express";
import cors from "cors";
import { calculatePrice } from "../src/pricing";
import type { Product } from "../src/types";

const app = express();
const port = Number(process.env.PORT ?? 3001);

app.use(cors());
app.use(express.json({ limit: "1mb" }));

function isProduct(value: unknown): value is Product {
  if (typeof value !== "object" || value === null) return false;
  const product = value as Record<string, unknown>;
  return (
    typeof product.sku === "string" &&
    typeof product.name === "string" &&
    typeof product.myPrice === "number" &&
    Number.isFinite(product.myPrice) &&
    typeof product.minPrice === "number" &&
    Number.isFinite(product.minPrice) &&
    typeof product.maxPrice === "number" &&
    Number.isFinite(product.maxPrice) &&
    typeof product.step === "number" &&
    Number.isFinite(product.step) &&
    Array.isArray(product.competitors) &&
    product.competitors.every((entry: unknown) => {
      if (typeof entry !== "object" || entry === null) return false;
      const competitor = entry as Record<string, unknown>;
      return (
        typeof competitor.seller === "string" &&
        typeof competitor.price === "number" &&
        Number.isFinite(competitor.price) &&
        typeof competitor.inStock === "boolean"
      );
    })
  );
}

app.post("/reprice", (req, res) => {
  if (!Array.isArray(req.body)) {
    res.status(400).json({ error: "Request body must be an array of products." });
    return;
  }

  if (!req.body.every(isProduct)) {
    res.status(400).json({ error: "Each product must match the Product schema." });
    return;
  }

  const results = (req.body as Product[]).map(calculatePrice);
  res.status(200).json(results);
});

app.listen(port, () => {
  console.log(`SaleScout API listening on http://localhost:${port}`);
});

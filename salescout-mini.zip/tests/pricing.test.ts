import { describe, expect, it } from "vitest";
import { calculatePrice } from "../src/pricing";
import type { Product } from "../src/types";

function product(overrides: Partial<Product> = {}): Product {
  return {
    sku: "SKU-1",
    name: "Test product",
    myPrice: 100_000,
    minPrice: 80_000,
    maxPrice: 120_000,
    step: 10,
    competitors: [{ seller: "Seller A", price: 99_000, inStock: true }],
    ...overrides
  };
}

describe("calculatePrice", () => {
  it("undercuts the lowest in-stock competitor", () => {
    expect(calculatePrice(product())).toEqual({
      sku: "SKU-1",
      oldPrice: 100_000,
      newPrice: 98_990,
      reason: "UNDERCUT"
    });
  });

  it("ignores competitors that are out of stock", () => {
    const input = product({
      competitors: [{ seller: "Unavailable", price: 1, inStock: false }]
    });
    expect(calculatePrice(input)).toMatchObject({
      newPrice: 120_000,
      reason: "NO_COMPETITORS"
    });
  });

  it("uses the minimum price when candidate falls below it", () => {
    expect(calculatePrice(product({
      minPrice: 95_000,
      competitors: [{ seller: "Cheap", price: 90_000, inStock: true }]
    }))).toMatchObject({ newPrice: 95_000, reason: "AT_MIN" });
  });

  it("uses the maximum price when candidate exceeds it", () => {
    expect(calculatePrice(product({
      maxPrice: 95_000,
      competitors: [{ seller: "Expensive", price: 150_000, inStock: true }]
    }))).toMatchObject({ newPrice: 95_000, reason: "AT_MAX" });
  });

  it("floors fractional candidate prices", () => {
    expect(calculatePrice(product({
      step: 0.5,
      competitors: [{ seller: "Seller", price: 34_999.9, inStock: true }],
      minPrice: 30_000,
      maxPrice: 40_000
    }))).toMatchObject({ newPrice: 34_999, reason: "UNDERCUT" });
  });

  it("does not let myPrice affect the calculation", () => {
    const input = product({ myPrice: 1 });
    expect(calculatePrice(input)).toMatchObject({ oldPrice: 1, newPrice: 98_990 });
  });

  it("uses the lowest price among in-stock competitors", () => {
    expect(calculatePrice(product({
      competitors: [
        { seller: "A", price: 98_000, inStock: true },
        { seller: "B", price: 95_000, inStock: true },
        { seller: "C", price: 1, inStock: false }
      ]
    }))).toMatchObject({ newPrice: 94_990, reason: "UNDERCUT" });
  });

  it("handles empty competitor list", () => {
    expect(calculatePrice(product({ competitors: [] }))).toMatchObject({
      newPrice: 120_000,
      reason: "NO_COMPETITORS"
    });
  });
});

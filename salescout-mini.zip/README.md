# SaleScout — mini price bot

Мини-проект для пересчёта цен продавца на Kaspi.kz. Реализованы чистая функция расчёта цены, Express API, React-интерфейс сравнения «было / стало» и unit-тесты.

## Требования

- Node.js 20+
- npm

## Установка и запуск

```bash
npm install
```

Запустите API в первом терминале:

```bash
npm run dev:server
```

API будет доступен на `http://localhost:3001`.

Во втором терминале запустите React/Vite:

```bash
npm run dev:client
```

Откройте `http://localhost:5173`. Vite проксирует `/reprice` на Express API.

## Тесты и сборка

```bash
npm test
npm run build
```

## API

`POST http://localhost:3001/reprice`

Заголовок: `Content-Type: application/json`

Тело запроса — массив объектов `Product`. Успешный ответ — массив `PriceResult` в том же порядке. Если тело не является массивом или товар не соответствует ожидаемой структуре, API отвечает `400`.

Пример с файлами из `data/`:

```bash
curl -X POST http://localhost:3001/reprice \
  -H 'Content-Type: application/json' \
  --data @data/products.json
```

## Алгоритм `calculatePrice`

1. Учитываются только конкуренты с `inStock: true`.
2. Если конкурентов в наличии нет, возвращается `maxPrice` и `NO_COMPETITORS`.
3. Иначе выбирается минимальная цена конкурента, вычисляется `Math.floor(best - step)`.
4. Кандидат ограничивается `minPrice` и `maxPrice`; причина — `AT_MIN`, `AT_MAX` или `UNDERCUT`.
5. `myPrice` не участвует в расчёте и возвращается без изменений как `oldPrice`.

Функция находится в `src/pricing.ts` и экспортируется как именованный `calculatePrice`. Типы находятся в `src/types.ts`.

## Структура проекта

```text
src/
  pricing.ts       # Чистая функция, фиксированный путь по заданию
  types.ts         # Типы домена
  App.tsx          # React-страница
  main.tsx         # Точка входа React
  styles.css       # Стили интерфейса
server/
  index.ts         # Express API
tests/
  pricing.test.ts  # Unit-тесты Vitest
data/
  products.json    # Демонстрационные товары
  expected.json    # Ожидаемый результат
```

## Коммиты

При публикации репозитория используйте небольшие осмысленные коммиты, например:

```text
feat: implement pure price calculation
test: cover pricing boundaries and stock filtering
feat: add Express repricing endpoint
feat: build React price comparison table
docs: add setup and API instructions
```

Не загружайте `node_modules` и не коммитьте секреты. Перед отправкой проверьте `npm test` и `npm run build`.

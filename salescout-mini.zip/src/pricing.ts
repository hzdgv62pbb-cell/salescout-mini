import type { Product, PriceResult, Reason } from "./types";

export function calculatePrice(product: Product): PriceResult {
  const availableCompetitors = product.competitors.filter(
    (competitor) => competitor.inStock
  );

  let newPrice: number;
  let reason: Reason;

  if (availableCompetitors.length === 0) {
    newPrice = product.maxPrice;
    reason = "NO_COMPETITORS";
  } else {
    const best = Math.min(...availableCompetitors.map(({ price }) => price));
    const candidate = Math.floor(best - product.step);

    if (candidate < product.minPrice) {
      newPrice = product.minPrice;
      reason = "AT_MIN";
    } else if (candidate > product.maxPrice) {
      newPrice = product.maxPrice;
      reason = "AT_MAX";
    } else {
      newPrice = candidate;
      reason = "UNDERCUT";
    }
  }

  return {
    sku: product.sku,
    oldPrice: product.myPrice,
    newPrice,
    reason
  };
}

import { useState } from "react";
import type { Product, PriceResult, Reason } from "./types";

const sampleProducts: Product[] = [
  {
    sku: "PHONE-001",
    name: "Смартфон Nova X 256 ГБ",
    myPrice: 389990,
    minPrice: 370000,
    maxPrice: 420000,
    step: 10,
    competitors: [
      { seller: "TechMarket", price: 384990, inStock: true },
      { seller: "Gadget City", price: 386000, inStock: true },
      { seller: "Budget Store", price: 379990, inStock: false }
    ]
  },
  {
    sku: "HEAD-014",
    name: "Наушники AirBeat Pro",
    myPrice: 175000,
    minPrice: 180000,
    maxPrice: 210000,
    step: 100,
    competitors: [{ seller: "Audio Hub", price: 175000, inStock: true }]
  },
  {
    sku: "WATCH-203",
    name: "Смарт-часы Pulse 3",
    myPrice: 124990,
    minPrice: 80000,
    maxPrice: 125000,
    step: 1,
    competitors: [{ seller: "Wearables KZ", price: 150000, inStock: true }]
  },
  {
    sku: "MOUSE-009",
    name: "Беспроводная мышь",
    myPrice: 15990,
    minPrice: 12000,
    maxPrice: 22000,
    step: 50,
    competitors: []
  }
];

const reasonLabels: Record<Reason, string> = {
  UNDERCUT: "Ниже конкурента",
  AT_MIN: "Минимальная цена",
  AT_MAX: "Максимальная цена",
  NO_COMPETITORS: "Нет конкурентов в наличии"
};

const formatPrice = (price: number) =>
  new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 }).format(price) + " ₸";

export default function App() {
  const [products, setProducts] = useState<Product[]>(sampleProducts);
  const [results, setResults] = useState<PriceResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function reprice() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/reprice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(products)
      });
      if (!response.ok) {
        const payload: unknown = await response.json();
        const message =
          typeof payload === "object" && payload !== null && "error" in payload
            ? String(payload.error)
            : "Не удалось пересчитать цены";
        throw new Error(message);
      }
      const data: unknown = await response.json();
      if (!Array.isArray(data)) throw new Error("Сервер вернул неожиданный ответ");
      setResults(data as PriceResult[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Неизвестная ошибка");
    } finally {
      setLoading(false);
    }
  }

  function updatePrice(sku: string, value: string) {
    const parsed = Number(value);
    setProducts((current) =>
      current.map((product) =>
        product.sku === sku && value.trim() !== "" && Number.isFinite(parsed)
          ? { ...product, myPrice: parsed }
          : product
      )
    );
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="/" aria-label="SaleScout home">
          <span className="brand-mark">S</span>
          <span>Sale<span className="brand-light">Scout</span></span>
        </a>
        <span className="status"><span className="status-dot" /> Price monitor</span>
      </header>

      <section className="intro">
        <p className="eyebrow">KASPI.KZ · SMART REPRICING</p>
        <h1>Ваши цены.<br /><span>Под контролем.</span></h1>
        <p className="intro-copy">
          Следите за конкурентами и рассчитывайте конкурентную цену, не опускаясь ниже вашего минимума.
        </p>
      </section>

      <section className="metrics" aria-label="Сводка">
        <div className="metric-card">
          <span className="metric-label">Товаров в списке</span>
          <strong>{products.length.toString().padStart(2, "0")}</strong>
          <span className="metric-foot">Готовы к пересчёту</span>
        </div>
        <div className="metric-card">
          <span className="metric-label">Пересчитано</span>
          <strong>{results.length.toString().padStart(2, "0")}</strong>
          <span className="metric-foot">Результаты API</span>
        </div>
        <div className="metric-card">
          <span className="metric-label">На минимуме</span>
          <strong>{results.filter((item) => item.reason === "AT_MIN").length.toString().padStart(2, "0")}</strong>
          <span className="metric-foot">Ниже опускаться нельзя</span>
        </div>
      </section>

      <section className="table-panel">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">CATALOG OVERVIEW</p>
            <h2>Мониторинг цен</h2>
            <p className="muted">Измените старую цену при необходимости, затем запустите пересчёт.</p>
          </div>
          <button className="reprice-button" onClick={reprice} disabled={loading}>
            {loading ? <><span className="spinner" /> Считаем…</> : "↻ Пересчитать цены"}
          </button>
        </div>

        {error && <div className="error-banner" role="alert">{error}</div>}

        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Товар</th>
                <th>SKU</th>
                <th>Было</th>
                <th>Стало</th>
                <th>Причина</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => {
                const result = results.find((item) => item.sku === product.sku);
                return (
                  <tr key={product.sku}>
                    <td>
                      <div className="product-cell">
                        <span className="product-icon">{product.name.slice(0, 1).toUpperCase()}</span>
                        <span className="product-name">{product.name}</span>
                      </div>
                    </td>
                    <td><span className="sku">{product.sku}</span></td>
                    <td>
                      <label className="price-input-wrap">
                        <input
                          aria-label={`Старая цена ${product.name}`}
                          type="number"
                          min="0"
                          value={product.myPrice}
                          onChange={(event) => updatePrice(product.sku, event.target.value)}
                        />
                        <span>₸</span>
                      </label>
                    </td>
                    <td>
                      {result ? (
                        <span className="new-price">{formatPrice(result.newPrice)}</span>
                      ) : <span className="not-calculated">—</span>}
                    </td>
                    <td>
                      {result ? (
                        <span className={`reason reason-${result.reason.toLowerCase()}`}>
                          <span className="reason-dot" />{reasonLabels[result.reason]}
                        </span>
                      ) : <span className="not-calculated">Ожидает</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="table-footer">
          <span><span className="live-dot" /> Демо-данные · API подключён через /reprice</span>
          <span>Валюта: KZT (₸)</span>
        </div>
      </section>

      <footer><span>SaleScout</span><span>Умное ценообразование для продавцов Kaspi.kz</span></footer>
    </main>
  );
}
